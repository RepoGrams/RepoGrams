CREATE TABLE url2data (
  id INTEGER NOT NULL AUTO_INCREMENT,
  url TEXT,
  frequency INTEGER,
  folder TEXT,
  PRIMARY KEY(id)
);

<div id="footer" class="navbar navbar-fixed-bottom">
	<div class="container">
		<p class="muted credit">&copy;<?php date_default_timezone_set ( 'UTC' );echo date("Y")?> Fabian Kosmale, Heiko Becker, Maike Maas, Marc Jose, Sebastian Becking, Valerie Poser</p>	
	</div>
</div>

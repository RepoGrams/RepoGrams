<div class="col-md-12 center-block">
	<div style="width:292; display:block; margin:auto auto 0;" class="panel panel-default">
  		<div class="panel-heading">
    		<h3 class="panel-title">Example</h3>
  		</div>
  	<div style="width:300;height:80px;boder-style:solid; padding-left: 0 !important; padding-top: 0 !important;" class="custom panel-body">
		<ul style="display:inline-block; list-style-type:none !important; padding-left:0 !important;">
			<li class="customBlock" id="1" style="background-color:rgb(0,128,255); width:290px; height:20px;" data-html="true" 
			data-original-title="This is one element of a chromogram. Hover over the different items to get detailed information."
			data-placement="right" rel="tooltip"></li>
			<li class="customBlock" id="2" style="background-color:rgb(260,0,66); width:110px; height:20px;" data-html="true" 
			data-original-title="Thats the way you do it. Each block in your chromogram represents one commit of your repository."
			data-placement="right" rel="tooltip"></li>
			<li class="customBlock" id="3" style="background-color:rgb(98,226,0); width:180px; height:20px;" data-html="true" 
			data-original-title="Ok, you got the concept. The first rendering is fixed by us. The next one can be parametrized."
			data-placement="right" rel="tooltip"></li>
			<li class="customBlock" id="4" style="background-color:rgb(98,226,0); width:290px; height:20px;" data-html="true" 
			data-original-title="Ok, you got the concept. The first rendering is fixed by us. The next one can be parametrized."
			data-placement="right" rel="tooltip"></li>
			<li class="customBlock" id="5" style="background-color:rgb(255,226,0); width:200px; height:20px;" data-html="true" 
			data-original-title="It's up to you to decide wether you want the author, the commit time or line changes to incluence your image."
			data-placement="right" rel="tooltip"></li>
			<li class="customBlock" id="6" style="background-color:rgb(0,128,255); width:90px; height:20px;" data-html="true" 
			data-original-title="Downloading is possible too. You can get svg, png and even pdf."
			data-placement="right" rel="tooltip"></li>
		</ul>
	</div>
</div>

